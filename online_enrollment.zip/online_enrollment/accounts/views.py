from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib import messages
from .models import Student
from .forms import StudentForm

def login_user(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('students_list')  # Redirect to student list after login
        else:
            messages.error(request, 'Invalid username or password')
    return render(request, 'accounts/login.html')


def logout_user(request):
    logout(request)
    return redirect('login')


def register(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        password2 = request.POST['password2']

        if password != password2:
            messages.error(request, "Passwords do not match")
            return redirect('register')

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists")
            return redirect('register')

        user = User.objects.create_user(username=username, password=password)
        messages.success(request, "Account created successfully")
        return redirect('login')

    return render(request, 'accounts/register.html')

@login_required
def students_list(request):
    students = Student.objects.filter(user=request.user)
    return render(request, 'accounts/students_list.html', {'students': students})


@login_required
def add_student(request):
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            student = form.save(commit=False)
            student.user = request.user
            student.save()
            return redirect('students_list')
    else:
        form = StudentForm()
    return render(request, 'accounts/add_student.html', {'form': form})


@login_required
def edit_student(request, id):
    student = get_object_or_404(Student, id=id, user=request.user)
    if request.method == 'POST':
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            return redirect('students_list')
    else:
        form = StudentForm(instance=student)
    return render(request, 'accounts/edit_student.html', {'form': form})


@login_required
def delete_student(request, id):
    student = get_object_or_404(Student, id=id, user=request.user)
    if request.method == 'POST':
        student.delete()
        return redirect('students_list')
    return render(request, 'accounts/delete_student.html', {'student': student})
